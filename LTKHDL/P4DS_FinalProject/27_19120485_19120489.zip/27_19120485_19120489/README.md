# P4DS_FinalProject

Đồ án cuối kì môn học Lập trình cho khoa học dữ liệu
MSSV | Họ và tên | Link github |
--- | --- | --- |
19120485 | Nguyễn Phạm Quang Dũng | https://github.com/npqd |
19120489 | Lưu Trường Dương | https://github.com/robocon20x |

## Link trello
https://trello.com/ltkhdl_finalproject

